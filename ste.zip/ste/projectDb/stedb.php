
<?php
ob_start();
session_start();

$dbservername="localhost";
$dbuser="root";
$dbpass="";
$dbname="ste";
$conn=mysqli_connect($dbservername,$dbuser,$dbpass,$dbname);
?>