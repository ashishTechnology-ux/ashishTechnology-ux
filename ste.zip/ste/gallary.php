<!doctype html>
<html>
<head>

<head>
<?php
include "include/Head_Content.php";

?>
		

</head>

<body>

<?php
	
	include "include/header_nav.php";


	?>
	
	<br>
	<br>
<div class="container-fluid">
<div class="jumbotron";>
<div class="card">
<h1 class="card-title text-center">GALLERY IMAGE</h1><br>	
<div class="row">
<?php
	$dir="images/";
	$files=scandir($dir);
	if($files){
    foreach($files as $file){
?>
<div class="col-12 col-sm-6 col-md-4 col-lg-3 col-xl-2 border"><img src="images/<?php echo $file;?>" alt="img" class="img-thumbnail"></div>
<?php
	}
	
	}else{
		
	?>
<h1 class=" card-title text-warning fa-border">No images on folder</h1>
<?php
	}
		?>
</div>
</div>	
	
</div>

</div>
</body>
</html>