<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>About_us</title>
<?php 
	include "include/Head_Content.php";
	?>
</head>

<body>
<?php 
	include  "include/header_nav.php";
?>
	
<div class="container">
<div class="jumbotron">
<div class="media border">
<div class="media-left">
<img src="images/puspa.jpg" class="media-object img-rounded" width="120px">
	</div>
	<div class="media-body">
	<h4 class="media-heading mt-4">Puspa Bhattrai</h4>
	<p>Comming soon</p>
	</div>
</div>	
</div>
	</div>
</body>
</html>