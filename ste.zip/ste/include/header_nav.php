
	<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
  <a class="navbar-brand text-secondary" href="#">Company Name</a>
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar" >
    <ul class="navbar-nav ml-auto text-center">
      <li class="nav-item">
        <a class="nav-link active" href="index.php">Home</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="contact.php">Contact</a>
      </li>
      <li class="nav-item">
        <a class="nav-link " href="about.php">About_Us</a>
      </li>  
      <li class="nav-item">
        <a class="nav-link " href="gallary.php">Gallary</a>
      </li>	
	  <li class="nav-item">
        <a class="nav-link " href="admin/index.php">Admin</a>
      </li>
    </ul>
  
</nav>



    

