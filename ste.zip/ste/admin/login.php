<!doctype html>
<html>
<head>
<?php
		 include "../projectDb/stedb.php";
		include "../include/Head_Content.php";
	
		
		?>
<title>Login</title>
</head>

<body>
	<header>
		<?php
	include "../include/header_nav.php"
	?>
	</header>
	
	
	
	<h4 style="color:white; background-color:black; text-align:center; border-color:red; border:dotted;">Login-Form</h4>
	<br>
<div style="color:red; text-align: center;">
	<?php
			if(isset($_SESSION['message'])){
			echo $_SESSION['message'];
			unset($_SESSION['message']);
			}
			
			?>
	
	</div>
	<content>
	
	</content>
</body>
</html>