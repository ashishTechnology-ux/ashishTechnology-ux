<html>
<head>
<?php
include "../include/Head_Content.php";
include "../projectDb/stedb.php";

?>
		<script src="../js/ckeditor/ckeditor.js"></script>
	
	
</head>

<body>
	<?php
			
			include "admin_nav.php";
			
			
			?>
	<br>
	
	
	<div class="row">

		<div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-4">
	      <?php
			
			include "card.php";
			
			
			?> 
		</div>
	
		<?php
		if(isset($_GET['id'])){
			
			$id=$_GET['id'];
		    $id=mysqli_real_escape_string($conn,$id);
			$id=htmlentities($id);
			$sql="select * from posts where id='$id'";
			$res=mysqli_query($conn,$sql);
			if(mysqli_num_rows($res)>0){
			 $row=mysqli_fetch_assoc($res); 
		
		?>
	

	<div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8">

	<div class="card">
		<div class="card-title text-center">TITLE FOR POST</div>
		<div class="card-title text-center">
			<?php
					
					if(isset($_SESSION['message'])){
						echo $_SESSION['message'];
						unset($_SESSION['message']);
					}
			
					?>
		
		</div>
	<div class="card-body">
	<form action="update.php?id=<?php echo $id;?>" method="post">
	
  
<textarea class="form-control" name="title" placeholder="TITLE" rows="1"><?php echo $row['title'];?></textarea>
		
	
		
<div class="form-group" >

  <textarea class="form-control ckeditor" name="ckeditor" rows="5"  ><?php echo $row['content'];?></textarea>
	<br>
	<div><button class="btn btn-primary mx-auto d-block" name="update">Update</button>
</div>
		</div>

</form>
		
		
	
	</div>
	
	</div>
	</div>
	<div class="text-warning">
	
	
	</div>
		<?php
			}
		}else{
			header("Location:dashboard.php");
		}
				?>
		</body>
	</html>