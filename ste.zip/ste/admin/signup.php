<?php

include "../projectDb/stedb.php";
if(isset($_POST['signup'])){
	$name=$_POST['name'];
$address=$_POST['address'];
$email=$_POST['email'];
$pass=$_POST['pass'];
$name=mysqli_real_escape_string($conn,$name);
$address=mysqli_real_escape_string($conn,$address);
$email=mysqli_real_escape_string($conn,$email);
$pass=mysqli_real_escape_string($conn,$pass);
$name=htmlentities($name);
$address=htmlentities($address);
$email=htmlentities($email);
$pass=htmlentities($pass);
$pass=password_hash($pass,PASSWORD_BCRYPT);
$sql="select * from userdetail where email='$email' or name='$name'";
$res=mysqli_query($conn,$sql);	
if(mysqli_num_rows($res)>0){
	header("location:login.php");
	$_SESSION['message']="Account already existed!please login";
}
else{
	
	$sql1="insert into userdetail(name,address,email,password) values('$name','$address','$email','$pass')";
	$res1=mysqli_query($conn,$sql1);
	if($res1){
	header("Location:index.php");
	$_SESSION['message']="Registered successfully, please login";	
		
	}
	else{
		header("Location:login.php");
	$_SESSION['message']="Something went wrong,please signup again.";	
	}
}
	
}


	
?>