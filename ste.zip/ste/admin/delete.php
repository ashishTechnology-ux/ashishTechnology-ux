<?php
include "../include/Head_Content.php";
include "../projectDb/stedb.php";
if(isset($_GET['id'])){
$id=$_GET['id'];
$id=mysqli_real_escape_string($conn,$id);	
$id=htmlentities($id);
$sql="delete from posts where id=$id";
$res=mysqli_query($conn,$sql);
		if(res){
			header("Location:dashboard.php");
			$_SESSION['message']="<div class='text-success'>your post is successfully deleted</div>";
			
		}else{
			header("Location:dashboard.php");
			$_SESSION['message']="<div class='text-warning'>something went wrong</div>";
		}
	}
	


	


?>