<?php
include "../projectDb/stedb.php";

if(isset($_GET['id'])){
	
	


include "../include/Head_Content.php";
if(isset($_POST['update'])){
 $id=$_GET['id'];
 $title=$_POST['title'];
 $data=$_POST['ckeditor'];
 $id=mysqli_real_escape_string($conn,$id);
$title=mysqli_real_escape_string($conn,$title);
$data=mysqli_real_escape_string($conn,$data);
$id=htmlentities($id);
$title=htmlentities($title);
$data=htmlentities($data);
 $sql="update posts set title='$title', content='$data' where id=$id";
$res=mysqli_query($conn,$sql);
		if(res){
			header("Location:dashboard.php");
			$_SESSION['message']="<div class='text-success'>your post is successfully updated</div>";
		}else{
			header("Location:edit.php");
			$_SESSION['message']="<div class='text-warning'>something went wrong</div>";
		}
	}
	

}
	


?>