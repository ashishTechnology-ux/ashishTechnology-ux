<div class="nav flex-column">
	<?php
	
	        include "../include/Head_Content.php";
	        include "../projectDb/stedb.php";
	?>
       

<div class="card" style="width:400px">
  <img class="card-img-top" src="../images/p3.jpg" alt="Card image" style="width:200px;border-radius:50%; margin-left:22%">
  <div class="card-body">  
    <h4 class="card-title text-center"><?php  echo $_SESSION['username']; ?></h4>
	<h4 class="card-title text-center"><?php $username= $_SESSION['username'];
			$sql="select * from userdetail where name='$username'";
			$res=mysqli_query($conn,$sql);
			$row=mysqli_fetch_assoc($res);
			$email=$row['email'];
			echo $email;
		 ?></h4>
  <ul class="list-group">
	<li class="list-group-item list-group-item-action text-center"><a href="dashboard.php" class="nav-link">Dashboard</a></li>  
	  <li class="list-group-item list-group-item-action text-center"><a href="post.php" class="nav-link">Post</a></li>
	  <li class="list-group-item list-group-item-action text-center"><a href="show_image.php" class="nav-link">Images</a></li> 
	  <li class="list-group-item list-group-item-action text-center"><a href="" class="nav-link">Setting</a></li> 
	  <li class="list-group-item list-group-item-action text-center"><a href="logout.php" class="nav-link">LogOut</a></li>
	 
  </ul>
	  
	</div>
	<div class="card-footer">
	 <a href="https://www.facebook.com/weLiveForOthers" class="btn btn-primary"style="margin-left:30%">See Profile</a>
	</div>
</div>
</div>