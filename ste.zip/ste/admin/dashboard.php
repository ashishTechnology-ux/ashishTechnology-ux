
<html>
<head>

	
	</head>

<body>
	
	<?php
       		
			include "admin_nav.php";
			
			
			?>
		<br><br>
	
		<div class="row">
		<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-4">
		<?php
			        
			
			include "card.php";
			?>
		
		
		
	  <br>
			
   
 
			</div>
  
			<div class="col-12 col-sm-12 col-md-12 col-lg-12 col-xl-8"><h1 class="mx-auto">
				<?php
					
					if(isset($_SESSION['message'])){
						echo $_SESSION['message'];
								unset($_SESSION['message']);
					}
			
					?>
				<!---database action on publish*-->
				<?php


            
			if(isset($_SESSION['username'])){
				
			
			
	  ?>
			
				<ul class="list-group" style="font-size:14pt;">
					<?php
				
	             $sql="select * from posts order by id desc";
				 $res=mysqli_query($conn,$sql);
				 if(mysqli_num_rows($res)>0){
					
				 while($row=mysqli_fetch_assoc($res)){
					?>
				<li class="list-group-item">Recent Post</li>	
				<li class="list-group-item"><?php echo $row['title']?>
				<br>
				<div> 
				
				<span><a href="edit.php?id=<?php echo $row['id'];?>"> <i class="fa fa-edit">edit</i></a>|<a href="delete.php?id=<?php echo $row['id'];?>" ><i class="fa fa-trash">Delete</i></a></i>|<a href=""><i class="fa fa-share">share</i></a></span>
				</li>
					
				<?php
				 }
				 }
				?>
				</ul>
                 
			
			</div>
</div>
			
<?php
	   
				
			}else{
				
				header("Location:index.php");
				$_SESSION['message']="<div class='text-warning'>please login to continue</div>";
			}
				
?>			

	
	
</body>
</html>
