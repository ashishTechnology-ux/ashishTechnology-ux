<!doctype html>
<html>
<head>
<?php
		
		include "../include/Head_Content.php";
	    include "../projectDb/stedb.php";
		
		?>
		<script src="../js/signup_validation.js"></script>
<title>Signup</title>
</head>

<body>
	
	
		<?php
	include "../include/header_nav.php";
	?>
	</header>
	
	
	<br><br>

	<div class="jumbotron">
<?php
			if(isset($_SESSION['message'])){
			echo $_SESSION['message'];
			unset($_SESSION['message']);
			}
			
			?>
	<div class="container">
	
	<ul class="nav nav-tabs">
	<li class="nav-item">
	<a href="#signup" class="nav-link" data-toggle="tab">signup</a>	
	</li>	
	<li class="nav-item">
	<a href="#login" class="nav-link" data-toggle="tab">Login</a>	
	</li>	
	</ul>
	
	<div class="tab-content">
	<div id="signup" class="container tab-pane active">
	
	
	<form action="signup.php" style="margin-left:20px;" method="post">
 	<div class="form-group">
    <label for="name">Name:</label>
    <input type="text" class="form-control" id="name" name="name" required placeholder="Enter your Name">
	<div id="name_error"></div>
  </div>
  <div class="form-group">
    <label for="address">Address:</label>
    <input type="text" class="form-control" id="address" name="address" required placeholder="Enter your Address">
	<div id="address_error"></div>
  </div>
		<div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your Email_ID">
	<div id="email_error"></div>
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name="pass" required placeholder="Enter your Password">
	<div id="pass_error"></div>
  </div>
   <div class="form-group">
    <label for="cfrm_pwd">Confirm_Password:</label>
    <input type="password" class="form-control" id="cpwd" required placeholder="Confirm your Password">
	<div id="cfrm_pass_error"></div>
  </div>
 
  <button type="submit" name="signup" class="btn btn-primary" id="signup_btn">Submit</button>
		</form>
		</div>
		
	<div id="login" class="container tab-pane fade active">
	
		
	<form  action="loginprocess.php" method="post" style=" margin:20px; ckground-color:antiquewhite; border-style: double;" >
      
		<div class="form-group">
    <label for="email">Email address:</label>
    <input type="email" class="form-control" id="email" name="email" required placeholder="Enter your Email">
  </div>
  <div class="form-group">
    <label for="pwd">Password:</label>
    <input type="password" class="form-control" id="pwd" name="pass" required placeholder="Enter your Password">
  </div>
		<div class="form-group form-check">
    <label class="form-check-label">
      <input class="form-check-input" type="checkbox"> Remember me
    </label>
  </div>
 
  <button type="submit" name="login" class="btn btn-primary">Submit</button>
</form>
	</div>
		
		

	
	</div>
	</div>
	</div>
	
</body>
</html>