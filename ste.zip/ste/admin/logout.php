<?php

include "../projectDb/stedb.php";
if(isset($_SESSION['username'])){
unset($_SESSION['username']);
session_destroy();
$_SESSION['message']="<div class='text-success'>you are sucessfully logout</div>";	
header("Location:index.php");

}
else{
$_SESSION['message']="<div class='text-warning'>please continue to login</div>";	
header("Location:index.php");	
	
}
?>