<!DOCTYPE HTML>
<?php
        include "../projectDb/stedb.php";

        if(isset($_POST['upload'])){
		for($i=0; $i < count($_FILES['image']['name']); $i++){
			
			
		$filesname=$_FILES['image']['name'][$i];
		$tmplocation=$_FILES['image']['tmp_name'][$i];
		$files_size=$_FILES['image']['size'][$i];
		$filext= explode('.',$filesname);
		$filextcheck=strtolower(end($filext));
		$filextstored=array('jpg','png','jpeg');
		
		if(in_array($filextcheck,$filextstored)){
		if($files_size<=2097152){
	    move_uploaded_file($tmplocation,"../images/".$filesname);
		
		
	  }
	else{
		echo "<script> alert('do not match file type');</script>";
		exit();
	}	}else{
			echo "<script> alert('file size not exceeded than 2mb ');</script>";
		exit();
		
	}
		}	
		$_SESSION['message']="sucessfully uploaded!please wait..........";
		header("Location: loading.php");
			
		}	
		
       
		

?>
