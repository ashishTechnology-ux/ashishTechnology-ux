<?php
include "../projectDb/stedb.php";
if(isset($_POST['login'])){
$email=$_POST['email'];
$pass=$_POST['pass'];
$email=mysqli_real_escape_string($conn,$email);
$email=htmlentities($email);
$pass=mysqli_real_escape_string($conn,$pass);
$sql="select * from userdetail where email='$email'";
$res=mysqli_query($conn,$sql);
$row=mysqli_fetch_assoc($res); 
	$password=$row['password'];
	$username=$row['name'];
	if(password_verify($pass,$password)){
	
	
	header("Location:dashboard.php");
	$_SESSION['username']=$username;
	$_SESSION['message']="<div class='text-success'>Suceesfully login</div>";
	
	}
		
		else{
			
		header("Location:index.php");
		$_SESSION['message']="<div class='text-warning'>credentials donot match</div>";
			
		}

		



	}

?>