<!DOCTYPE html>
<html lang="en">
<head>
	<meta http-equiv="refresh" content="5;url=show_image.php">
	<?php
	include "../include/Head_Content.php";
	include "../projectDb/stedb.php";
	?>

	
</head>
	
	<body>
	
	
	<?php
		 if(isset($_SESSION['message'])){
			 echo $_SESSION['message'];
			 unset($_SESSION['message']);
		 }
		 ?>
		<br>
		
		<div class="spinner-border text-primary mx-auto d-block"></div>
	
	</body>