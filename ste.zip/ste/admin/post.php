<html>
<head>
<?php
include "../include/Head_Content.php";

?>
		<script src="../js/ckeditor/ckeditor.js"></script>
	
	
</head>

<body>
	<?php
			
			include "admin_nav.php";
			
			
			?>
	<br>
	
	
	<div class="row">

		<div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-4">
	      <?php
			
			include "card.php";
			
			
			?> 
		</div>
	

	<div class="col-12 col-sm-12 col-md-12 col-lg-8 col-xl-8">
     <div>
	<?php
		 if(isset($_SESSION['message'])){
			 echo $_SESSION['message'];
			 unset($_SESSION['message']);
		 }
		 ?>
		
	</div>
	<div class="card">
		<div class="card-title text-center">TITLE FOR POST</div>
	<div class="card-body">
	<form action="post.php" method="post" enctype="multipart/form-data">
	
<textarea class="form-control" name="title" placeholder="TITLE" rows="1"></textarea>

		
<div class="form-group" >

  <textarea class="form-control ckeditor" name="ckeditor" rows="5"  ></textarea>
	<br>
	<div><button class="btn btn-primary mx-auto d-block" name="publish">Published</button>
</div>
		</div>

</form>
		
	</div>
	
	</div>
	</div>
	
<?php
	if(isset($_POST['publish'])){
		
		$title=$_POST['title'];
		$data=$_POST['ckeditor'];
		$title=mysqli_real_escape_string($conn,$title);
		$data=mysqli_real_escape_string($conn,$data);
		$title=htmlentities($title);
		$data=htmlentities($data);
	$sql="insert into posts(title,content)values('$title','$data')";
		$res=mysqli_query($conn,$sql);
		 if(res){
			header("Location:dashboard.php");
			$_SESSION['message']="<div class='text-success'>your post is successfully published</div>";
		}else{
			header("Location:dashboard.php");
			$_SESSION['message']="<div class='text-warning'>something went wrong</div>";
		}
			
		

	
		
	}?>
		
	  
</body>


</html>

