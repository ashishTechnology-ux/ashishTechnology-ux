<!doctype html>
<html>
<head>

<head>

		

</head>

<body>

<?php
	
	include "admin_nav.php";


	?>
	
	<br>
	<br>
<div class="container-fluid">


<h1 class=" text-center">GALLERY IMAGE</h1><br>	
<div class="row">
<div class="col-sm-4 ">
	<?php
	
	include "card.php";
	
	?>
	</div>
	<div class="col-sm-8">
		<div class="border">
			
<h5 class="text-center">featured image</h5>
<form class="form-inline mx-auto d-block" action="upload_img.php" method="post" enctype="multipart/form-data">
<input type="file" name="image[]" class="form-control-file " multiple required><br>
<button type="submit" class="btn btn-primary" name="upload">upload</button>
</form>
		</div>
	<div class="row">
		<?php
	$dir="../images/";
	$files=scandir($dir);
	if($files){
    foreach($files as $file){
?>


		<div class="col-sm-3 border"><img src="../images/<?php echo $file;?>" alt="img" class="img-thumbnail" height=200px></div>
	
<?php
	}
	
	}else{
		
		?>
		</div>
		</div>
		</div>
	
<h1 class="text-warning fa-border">No images on folder</h1>
<?php
	}
		?>
</div>
	
	
</div>

</body>
</html>
