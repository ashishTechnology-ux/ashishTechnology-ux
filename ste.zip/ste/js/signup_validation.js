$(document).ready(function(){

$('#signup_btn').click(function(){
	 var name=$('#name').val();
  var address=$('#address').val();
    var email=$('#email').val();
   var pass=$('#pwd').val();
   var cpass=$('#cpwd').val();
  if( name ==""){
	  $('#name_error').html("***required to fill this field");
	  $('#name_error').css("color","red");
	  return false;
  }
  if((name.length<=2) || (name.length>=26)){
	  
	   $('#name_error').html("***length of name must be more than 3 and less than 26");
	  $('#name_error').css("color","red");
	  return false; 
	  
  }
  if( address==""){
	  $('#address_error').html("***required to fill this field");
	  $('#address_error').css("color","red");
	  return false;
  }
  if( email==""){
	  $('#email_error').html("***required to fill this field");
	  $('#email_error').css("color","red");
	  return false;
  }
  if( pass==""){
	  $('#pass_error').html("***required to fill this field");
	  $('#pass_error').css("color","red");
	  return false;
  }
   if( cpass==""){
	  $('#cpass_error').html("***required to fill this field");
	  $('#cpass_error').css("color","red");
	  return false;
	
  }
    if(pass!=cpass){
	 
	   $('#cfrm_pass_error').html("***password donot match");
	  $('#cfrm_pass_error').css("color","red");
	  return false;
	
  }
});

});