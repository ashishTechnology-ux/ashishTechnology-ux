// JavaScript Document

// slide image

	<script>
	var image=["p1.jpg","p2.jpg","img1.jpg1","img2.jpg","bg1.jpg"];
		var i=0;
		function slide(){
			
			document.getElementById("slideshow").src=image[i];
			if(i<(image.length-1))			
				i++;
			else
				i=0;
			
		}
			
	
	</script>
