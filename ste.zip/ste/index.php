<!DOCTYPE html>
<html lang="en">
<head>
	<?php
	include "include/Head_Content.php";
	include "projectDb/stedb.php";
	?>

	
</head>
<body class="fa-border">
<header>
	<?php
	include "include/header_nav.php";
	?>
<div class="mx-auto d-block fixed ">
	<div class="mt-4 pt-4">	
<?php
	include "animation/carasoul.php";
	
	?>
	</div>
</div>
	
</header>
	
<br>
<content>
<article>
	<div class="conatiner">
	 <div class="text-center">
		 <div><marquee direction="left" scrollamount="20"><h4 style="color:red;">Welcome To Save The Earth</h4></marquee></div>
		</div>
   <div class="jumbotron">
		
	<?php
	$sql="select * from posts order by id desc limit 1";
	$res=mysqli_query($conn,$sql);
	
	if(mysqli_num_rows($res)>0){
	$row=mysqli_fetch_assoc($res);
		$title=$row['title'];
		$data=$row['content'];
		?>
		<h4 class="text-center text-capitalize"><?php echo $title;?></h4>
	   <br>
	<p class="pl-4 text-justify text-center "><?php echo htmlspecialchars_decode($data);?></h5>
	<?php
	}else{
		echo("Comming Soon");
	}
	
	?>
	
	
	
	
	
	</div>
     </div>
	 
	



</article>
</content>

<footer>
</footer>
	
	</body>	
	
</html>