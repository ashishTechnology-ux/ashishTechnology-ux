<!doctype html>
<html>
<head>
<meta charset="utf-8">
<?php
	include "include/Head_Content.php";
	include "projectDb/stedb.php";
	?>

</head>
	
	<?php
	include "include/header_nav.php";
	?>
<br>
		<br>
<div class="container">
	<div class="card mt-4">
		<h5 class="card-title text-center">Contact Detail</h5>
		<div class="card-body">
		<ul class="list-group">
			
		<li class="list-group-item"><prev>Address<i class="fa fa-location-arrow"></i>    :    enter your address</prev></li>	
		<li class="list-group-item"><prev>telephone<i class="fa fa-phone-square"></i>    :    enter your telephone number</prev></li>	
		<li class="list-group-item"><prev>Mobile<i class="fa fa-mobile"></i>      :    9827378742</prev></li>	
		<li class="list-group-item"><prev>Email<i class="fa fa-envelope-o"></i>          :    merogci@gmail.com</prev></li>	
				
		</ul>	
		
		</div>
		
		</div>
	</div>	 

<body>
</body>
</html>