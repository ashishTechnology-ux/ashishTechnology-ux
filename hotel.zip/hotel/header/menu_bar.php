<!DOCTYPE HTML>
<html>
<?php include "head.php";?>
<head>
<link href="../css/menu_bar.css" rel="stylesheet" type="text/css">	
	
</head>
<body>
<header>
<div class="logo">logo</div>	
<nav>
<ul>
	<li><a href="index.php">Home</a></li>	
<li><a href="#" class="down-arrow">Sunsari</a>
<ul class="sub-menu">
<li><a href="">Inaruwa</a></li>	
<li><a href="">Ramdhuni</a></li>	
<li><a href="">Ithari</a></li>
<li><a href="">Dharan</a></li>	
	
</ul>	
</li>	
<li><a href="#" class="down-arrow">Morang</a>
<ul class="sub-menu">
<li><a href="">Biratnagar</a></li>	
<li><a href="">Patthari</a></li>	
<li><a href="">Urlabari</a></li>
	
	
</ul>	
</li>	
<li><a href="#"class="down-arrow">Jhapa</a>
<ul class="sub-menu">
<li><a href="">Dhamak</a></li>	
	<li><a href="">Birtamode</a></li>	
<li><a href="">Kakarvitta</a></li>
<li><a href="">Charalee</a></li>	
	
</ul>	
</li>
<li><a href="illam.php">Illam</a></li>
<li><a href=""><span  class="glyphicon glyphicon-user text-white "></span >Signup</a></li>
<li ><a href="" ><span class="glyphicon glyphicon-log-in text-white"></span>Login</a></li>
</ul>
</nav>	
<div class="menu-toggle"><i class="fa fa-bars"></i></div>
</header>

	
	
</body>
</html>
<script>
$(document).ready(function(){
	$(".menu-toggle").click(function(){
		$("nav").toggleClass('active');
	});
	$('ul li').click(function(){
		$(this).siblings().removeClass('active');
		$(this).toggleClass('active');
		
	});
});

</script>

