<head>
<?php include "header/head.php"; ?>
	
<style>
	
	h1{
		animation:colorchange 2s infinite;
	}
	@keyframes colorchange{
		0%{color:white;}
		20%{color:red;}
		40%{color:aqua;}
		60%{color:antiquewhite;}
		80%{color:rosybrown;}
		100%{color:blueviolet;}
	}
	@media screen and (min-width: 400px) {
  h1 {
    font-size:14pt;
  }
}
		@media screen and (min-width: 700px) {
  h1 {
    font-size:16pt;
  }
}
			@media screen and (min-width: 1200px) {
  h1 {
    font-size:24pt;
  }
	
}
	

</style>
</head>
<body>

<div class="container">

<nav>
<div style="height: 50px;">
<?php include "header/menu_bar.php";?>
</div>


</nav>

<div class="jumbotorn bg-warning">
<h1 class="text-center font-weight-bold text-light mb-4">Hotel Name</h1>
<h1 class="text-center font-weight-bold text-light mb-4">Nepal's Fastest Growing Hotel Chain</h1><br>
<form action="" method="" class="form-inline justify-content-center mt-4 ">

<input type="text" name="place" placeholder="Ex:kathmandu" class="form-control " id="form_design">
<label id="form_design"><h5 class="text-light"> From:</h5></label>
<input type="date" name="From" class="form-control " id="form_design" >
	<label id="form_design"><h5 class="text-light">To:</h5></label>
<input type="date" name="To"  class="form-control" id="form_design">
&nbsp;<button id="form_design" class="btn btn-success btn-lg">Search</button>


</form>



	</div>
</div>

<div class="container">
<h2 class="font-weight-bolder">Trending Now</h2><br>
<content>
 <div class="row">
<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/1.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title">OJO Hotel Prince......</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/1.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title">OJO Hotel Prince......</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
	<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/1.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title">OJO Hotel Prince......</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/1.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title">OJO Hotel Prince......</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
	</div>
	<h2 class="font-weight-bolder">OJO featured</h2>
<div class="row">
<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/5.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title font-weight-bold">OJO Hotel Prince...</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text text-danger">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
<div class=" col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/6.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title font-weight-bold">OJO Hotel Prince....</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text text-danger">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
	<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/7.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title font-weight-bold">OJO Hotel Prince....</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text text-danger">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
<div class="col-6 col-sm-6 col-md-4 col-lg-3">
<div class="card" >
<img src="images/8.jpg" class="card-img-top img-thumbnail" alt="img" title="kathmandu">
<div class="card-body">
<h3 class="card-title font-weight-bold">OJO Hotel Prince...</h3>
<h4 class="card-text">Near Bagbazzar,Kathmandu</h4>
<h4 class="card-text text-danger">US-40$</h4>
<a href="a.html" class="stretched-link"></a>
</div>
 </div>	
</div>
	 </div>
</content>	

</div>
	
	<div class="container">

   <div class="jumbotron bg-dark">
	
	   <div>
		 <div>
		   <h4 class="text-center text-light font-weight-bold"> Nepal's Fastest Growing Hotel Chain</h4>
		   </div>
	      <div>
			    <h6 class="text-center text-light font-weight-lighter"> More Destinations. More Ease. More Affordable.</h6>
			   <br>
			   <div class="text-center text-white mt-4">1800+ cities/</div>
		   </div>
     
		</div>

		
</div>

</div>

	




</body>


  

