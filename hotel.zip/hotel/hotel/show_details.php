<style>

carasoul_item{
    height: 350px;
} 
img{
    height: 350px;
}

	.aminities{
		float:left;
		margin-left:20px;
	}
	@media screen and (min-width: 1200px) {
    #position_change {
       position:fixed;
	   width:700px;
    }
}
	@media screen and (min-width: 1000px) {
    #position_change {
       position:fixed; width:700px;
    }
}
	@media screen and (min-width: 480px) {
     #position_change{
       position:absolute; width:400px; margin-left: 20px;
		 margin-top:10px;
    }
}
@media screen and (min-width: 700px) {
     #position_change {
       position:inherit;  width:500px;
    }
}
	td{
		color:goldenrod;
		
		
	}
	input{
		width:130px;
		border-left:thick;
		
	}
	select{
		width:80px;
		height:28px;
	}
	
</style>

<?php
include "admin/include/dbase.php";
include "header/head.php";
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$id=mysqli_real_escape_string($obj->conn,$id);
	$sql="select * from hotel_details where id='$id'";
if($result=$obj->check($sql)){
	$row=$result->fetch_assoc();
  $name=$row['hotel_name'];
  $saddress=$row['street_address'];
}

	$sql1="select * from images where h_id='$id'";
if($result1=$obj->check($sql1)){
 while($row1=$result1->fetch_assoc()){
	 $a[]=$row1['image_name'];

	
 }


}
?>


<div class="container" style="margin-top: 50px;">


 <div class="300-px-wide">

   . <div id="myCarousel" class="carousel slide" data-ride="carousel">
    <!-- Indicators -->
    <ol class="carousel-indicators">
     <li class="carasoul_item" data-target="#myCarousel" data-slide-to="0" class="active"></li>
      <li class="carasoul_item" data-target="#myCarousel" data-slide-to="1"></li>
      <li class="carasoul_item" data-target="#myCarousel" data-slide-to="2"></li>
	    <li class="carasoul_item" data-target="#myCarousel" data-slide-to="3"></li>
		  <li class="carasoul_item" data-target="#myCarousel" data-slide-to="4"></li>
    </ol>

    <!-- Wrapper for slides -->
    <div class="carousel-inner">
      <div class="carousel-item active">
      <img src="admin/<?php echo $a[0];?>" alt="jpg" width="100%" >
    </div>
    <div class="carousel-item">
      <img src="admin/<?php echo $a[1];?>" alt="jpg" width="100%" >
    </div>
	   <div class="carousel-item">
      <img src="admin/<?php echo $a[2];?>" alt="jpg" width="100%" >
    </div>
      <div class="carousel-item">
      <img src="admin/<?php echo $a[3];?>" alt="jpg" width="100%" >
    </div>
      <div class="carousel-item">
      <img src="admin/<?php echo $a[4];?>" alt="jpg" width="100%" >
    </div>
   
   
    </div>

    <!-- Left and right controls -->
    <a class="left carousel-control" href="#myCarousel" data-slide="prev">
      <span class="glyphicon glyphicon-chevron-left"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="right carousel-control" href="#myCarousel" data-slide="next">
      <span class="glyphicon glyphicon-chevron-right"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>
</div>





<div style="margin-left: 80px;">
<h1 class="font-weight-bolder"><?php echo $name;?></h1>
<h4><?php echo $saddress;?></h4>	
</div>

</div>
 <?php
	
}else{
	echo "no data";
}
?>
<div class="container">
<div>
<?php include "header/menu_bar.php";?>
</div>
<div class="row">
	
<div class="col-12 col-sm-12 col-md-6 col-lg-7">
<div class="card">
	<h4 class="card-header font-weight-bold"> <u>Description</u></h4>
	<div class="card-body">
	<h5 class="card-title">Location</h5>
	<p class="card-text">
		<?php echo $row['discription'];?>
		</p>	
		
</h4>


		
		
		
		</p>
	<br>
	<h4 class="font-weight-bolder text-center">Amenities</h4><br>
	<div>
	<div class="aminities"><i class='fa fa-wifi' style='font-size:24px'></i>free wifi</div>	
	<div class="aminities"><i class='fa fa-bed' style='font-size:24px'></i>Bed</div>	
	<div class="aminities"><i class='fa fa-tv' style='font-size:24px'></i>TV</div>	
	<div class="aminities"><i class='fa fa-plug' style='font-size:24px'></i>backup</div>
	</div>

	
	


	
	
</div>	
	
</div>

</div>

<div class="col-12 col-sm-12 col-md-6 col-lg-5">
<div class="card bg-secondary" id="position_change">
      <form action="admin/user/login.php" method="post">
	<input type="hidden" name="id" value="<?php echo $id?>">
	<div style="line-height:0; margin-left: 60px;" class="card-text text-white"><p><h2 class="text-danger">NPR&nbsp;<span ><input type="text" readonly name="price" class="bg-secondary" id="price" value="<?php echo $row['price']?>" style="border:none;"></span><span><strike class="text-dark"><small class="display-10 text-white discount">1500</small></strike>&nbsp;<span class="display-9">20%off</span></span></h2>per room per person</p>
	<h5 class="text-warning">Inclusive all taxes</h5>
	</div>
	<div class="card-body">
	
			<table style="margin-left:80px;">
			<tr><td>Check_in</td><td>check-out</td></tr>
			<tr><td><input id="date1" type="text"  name="date1"></td>
				<td><input id="date2" type="text"  onchange="calculation()" name="date2"></td></tr><br>
		
				<tr>
				<td>total room</td><td>total person</td>
				</tr>
				<tr>
			<td><select id="person" name="person" onchange="calculation()">
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
			</select ></td>
			<td><select id="room" name="room"  onchange="calculation()">
			<option value="1">1</option>
			<option value="2">2</option>
			<option value="3">3</option>
				<option value="4">4</option>
				<option value="5">5</option>
				<option value="6">6</option>
				<option value="7">7</option>
				<option value="8">8</option>
				<option value="9">9</option>
				<option value="10">10</option>
			</select></td>
				</tr>
			</table>
		
        <br>
		<button class="btn btn-success mx-auto d-block" name="booking" id="booking"  onclick="booking()">Book Now</button>

	
		<br>
		<td><h5 class="text-white font-weight-light">Enquiry:&nbsp;<i class="fa fa-phone text-dark" aria-hidden="true"></i>&nbsp;9827378742</h5></td>
	</form>
	</div>
</div>
</div><br>
<div class="mx-auto d-block">

</div>

</div>

</div>
<script>
function calculation(){
	var discount=20;
    var id=<?php echo $id?>;
    var amt=<?php echo $row['price'];?>;
	var date1=new Date($('#date1').val());
	var date2=new Date($('#date2').val());
	var room=$('#room').val();
	var person=$('#person').val();
	var datediff=date2.getTime()-date1.getTime();
	
	if(datediff==0){
		alert("select atleast 1 day");
		$('#date1').val("");
		$('#date2').val("");
	}else if(date2<date1){
		alert("check in is more than checkout");
		$('#date1').val("");
		$('#date2').val("");
	}else{
	var daysdiff=datediff/(1000*3600*24);  
	var total_price=parseInt(daysdiff)*room*person*amt;
	var total=total_price+(total_price *discount)/100;
	 $('.discount').html(total);	
    $('#price').val(total_price);	
	var datediff=date2.getTime()-date1.getTime();
	}
	

		
}
	 
$(document).ready(function(){

$("#date1").datepicker();
	$("#date2").datepicker();
var amt=<?php echo $row['price'];?>;
	var total=amt+(amt *20)/100;
	 $('.discount').html(total);

$()
	 jQuery.browser = {};
 (function () {
    jQuery.browser.msie = false;
    jQuery.browser.version = 0;
    if (navigator.userAgent.match(/MSIE ([0-9]+)\./)) {
       jQuery.browser.msie = true;
       jQuery.browser.version = RegExp.$1;
  }
 })();
});


</script>