
<div class="container">
<p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p><p>hello</p>
</div>
<?php
function pagination(){
	$page_buttons=10;
	$page_number=(isset($_GET['page']) AND !empty($_GET['page']))?$_GET['page']:1;
	$per_page_record=10;
	$rows=101;
	$last_page=ceil($rows/$per_page_record);
	$pagination="";
    $pagination .='<nav aria-label=""> ';
	$pagination .='<ul class="pagination">';
	if($page_number<1){
		$page_number=1;
		
	}else if($page_number>$last_page){
		$page_number=$last_page;
		
	}
	
	echo '<h3> showing page'.$page_number.'/'.$last_page.'</h3>';
	$half=floor($page_buttons/2);
	if($page_number<$page_buttons AND ($last_page==$page_buttons OR $last_page>$page_buttons)){
		for($i=1;$i<=$page_buttons;$i++){
			if($i==$page_number){
			$pagination .='<li class="active"><a href="pagination.php?page='.$i.'">'.$i.'<span class="sr-only">(current)</span></a></li>';	
			}else{
		$pagination .='<li><a href="pagination.php?page='.$i.'">'.$i.'</a></li>';
	}
		
	}
	if($last_page>$page_buttons){
		$pagination .='<li><a href="pagination.php?page='.($page_buttons+1).'">&raquo;</a></li>';
	}
}else if($page_number>=$page_buttons AND $rows>$page_buttons){
		$pagination .='<li><a href="pagination.php?page='.($last_page-$page_buttons).'">&laquo;</a></li>';	
		for($i=($last_page-$page_buttons)+1;$i<=$last_page;$i++);
	     if($i==$page_number){
			$pagination .='<li class="active"><a href="pagination.php?page='.$i.'">'.$i.'<span class="sr-only">(current)</span></a></li>';	
			}else{
		$pagination .='<li><a href="pagination.php?page='.$i.'">'.$i.'</a></li>';
	}
	}
$pagination .= '</ul></nav>';
echo $pagination;
}

?>



<?php


include "admin/include/dbase.php";
pagination();
?>
<link rel="stylesheet" href="css/bootstrap.css">
<script src="js/jquery-3.4.1.min.js" type="text/javascript"></script>