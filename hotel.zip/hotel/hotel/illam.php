<style>
	.image{
		border:2px gray red;
		height:80px;
		width:100px;
	}
	.link{
		margin-left: 150px;
	}
	li{
		float:left;
		display:inline;
		
	}
	.topborder{
		margin-top: 100px;
}
	
</style>
<?php
include "admin/include/dbase.php";
include "header/head.php";
?>
<div class="container">

	<?php
$sql="select * from hotel_details where city='illam'";
if($result=$obj->check($sql)){
while($row=$result->fetch_assoc()){

$sql1="select * from images where h_id='".$row['id']."'";
if($result1=$obj->check($sql1)){
 while($row1=$result1->fetch_assoc()){
	 $a[]=$row1['image_name'];
	
	
 }
	
?> 
<div><?php include "header/menu_bar.php";?></div>
<div class="card-deck border topborder">
<div class="card main_div"id="<?php echo $row['id'];?>">
<div class="card-body " >
<a href="show_details.php?id=<?php echo $row['id'];?>"><img  id="mainimg<?php echo $row['id']; ?>" src="admin/<?php echo $a[0]?>"  height="200px" width="410px" >	</a>
<div id="divcontainer<?php echo $row['id']; ?>">
<?php
	
for ($i=0;$i<4;$i++){
	
		
?>
<img src="admin/<?php echo $a[$i]?>" class="image">
<?php
}

?>
</div>	
</div>	
</div>
<div class="card">
<div class="card-body">
<h4 class="card-text font-weight-bold">OJO&nbsp;<?php echo $row['hotel_name'];?>&nbsp;Pvt Ltd</h4>
<h4 class="card-text"><?php echo $row['street_address'];?></h4><br>
<li class="list-group-item"><a href="#" title="Rating" data-toggle="popover" data-trigger="hover" data-content="1.5 &nbsp; good" styel="weight:20px;" class="btn-success">Rating:<span class="fa fa-star checked"></span></a></li>
<div>
<li class="list-group-item">First Aid</li>
<li class="list-group-item">Well Room</li>	
<li class="list-group-item">Dialy house keeping</li>	
<li class="list-group-item"><a href="show_details.php?id=<?php echo $row['id'];?>" style="text-decoration: none;">More....</a></li>	
</div>
<br>
<br>
<div class="card-footer mt-4">
	<h4 class="card-text"><?php echo $row['price'];?></h4>
	<h6 class="card-text">per room per night</h6>

		<div class="ml-5" ><a href="show_details.php?id=<?php echo $row['id'];?>" class="btn btn-warning"> View Details</a>
		&nbsp;<a href="admin/user/login.php?id=<?php echo $row['id'];?>" class="btn btn-success">Book Now</a>
		</div>
	
	
	
	
</div>	
</div>
</div>
</div>


<?php
	
}else{
	echo "no image found";
}
 $a=null;

?>

	<?php
	
}
	
}else{
	echo"no record found";
}

?>
	
</div>

<!-- jquery code for multiple images slide--->	
<script>
		


$(document).ready(function(){
$('.main_div').click(function(){
var img=$(this).attr('id');
	
 

$('#divcontainer'+img+'> img').on({
      onmouseover: function(){
	$(this).css({
		'cursor':'pointer',
		'border-color':'green'
	});
},
	onmouseout: function(){
		$(this).css({
			'cursor':'pointer',
		      'border-color':'grey'
			
		});
	},
		click: function(){
			 
			var imgurl=$(this).attr('src');
            $('#mainimg'+img).attr('src',imgurl);	
			
	
		}

	});
});
	 $('[data-toggle="popover"]').popover();   
});
</script>