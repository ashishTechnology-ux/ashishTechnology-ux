
<?php
include "../header/head.php";
include "include/dbase.php";

$table="";
		$table='<div class="jumbotron"><table class="table border-0">
		<tr><td>Costumer Name</td><td>customer_phone</td><td>Check_in</td><td>Check_Out</td><td>hotel name</td><td>hotel_phone</td><td>price</td></tr>';
	$sql="select * from booking_details order by id desc";
	if($result=$obj->check($sql)){
		
			
		while($row=$result->fetch_assoc()){
		$id=$row['id'];
		$table .='<tr>
		<td>'.$row['customer_name'].'</td>
		<td>'.$row['user_phone'].'</td>
		<td>'.$row['check_in'].'</td>
		<td>'.$row['check_out'].'</td>
		<td>'.$row['hotel_name'].'</td>
		<td>'.$row['hotel_phone'].'</td>
		<td>'.$row['total_price'].'</td>
		<td><a href="delete.php?id='.$id.'" class="btn btn-primary">delete</a></td>
		
		</tr>';	
			
		}
		
	}
$table .='</table></div>';
		echo $table;
		
?>
