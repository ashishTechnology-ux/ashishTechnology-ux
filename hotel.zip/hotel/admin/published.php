<?php
       require_once "include/dbase.php";
       require_once "../header/head.php";

        if(isset($_POST['published'])){
			
			/*data fetch from form*/
			$city=$_POST['city'];
			
			$street=$_POST['address'];
		    
			$hotel=$_POST['hotel'];
			$phone=$_POST['phone'];
			$email=$_POST['email'];
		    $price=$_POST['price'];
			$discription=$_POST['discription'];
			$street=mysqli_real_escape_string($obj->conn,$street);
			$email=mysqli_real_escape_string($obj->conn,$email);
			$city=mysqli_real_escape_string($obj->conn,$city);
			$hotel=mysqli_real_escape_string($obj->conn,$hotel);
			$phone=mysqli_real_escape_string($obj->conn,$phone);
			$price=mysqli_real_escape_string($obj->conn,$price);
			$discription=mysqli_real_escape_string($obj->conn,$discription);
		    $sql="insert into hotel_details(hotel_name,city,street_address,phoneno,email,price,discription)values('$hotel','$city','$street','$phone','$email','$price','$discription')";
			
			if($obj->insert($sql)){
				
		     $hid=$obj->conn->insert_id;
				/* files uploading*/
			
		for($i=0; $i < count($_FILES['images']['name']); $i++){
			
			
		$filesname=$_FILES['images']['name'][$i];
		$tmplocation=$_FILES['images']['tmp_name'][$i];
		$files_size=$_FILES['images']['size'][$i];
		$filext= explode('.',$filesname);
		$filextcheck=strtolower(end($filext));
		$filextstored=array('jpg','png','jpeg');
		$location="images/".$filesname;
		if(in_array($filextcheck,$filextstored)){
			
		if($files_size<=20097152){
	    move_uploaded_file($tmplocation,$location);
		$sql="insert into images(h_id,image_name)values('$hid','$location')";
	
		if($obj->insert($sql)){
			$obj->session("<div class='text-success'>successfully inserted</div>");
			header("Location:post.php");
		}else{
			$obj->session("<div class='text-danger'>not  inserted</div>");
			header("Location:post.php");
		}
	  }
	else{
		echo "<script> alert('do not match file type');</script>";
		exit();
	}	}else{
			echo "<script> alert('file size not exceeded than 2mb ');</script>";
		exit();
		
	}
		}
				
			}
			else{
				echo 'not inserted';
			}
			
	
			
			
		
		
			}
		
		

?>

