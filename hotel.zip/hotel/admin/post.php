<?php
include "../header/head.php";
include "include/dbase.php";

	

?>
<div class="container">
<div class="jumbotron">

	<h4>
	<?php
	if(isset($_SESSION['msg'])){
		echo $_SESSION['msg'];
		unset( $_SESSION['msg']);
	}
	if(isset($_SESSION['username'])){
		
		$username=$_GET['username'];
		$_SESSION['username']=$username;

	
	?>
	</h4>
<script src="../js/ckeditor/ckeditor.js"></script>
<form  action="published.php" method="post" enctype="multipart/form-data">
<div class="card-deck">
<div class="card">
<h4 class="card-title text-center">Hotel Detail</h4>
<div class="card-body">

<div class="form-group">
<label for="cityi">City Name:</label>
<input type="text" name="city" class="form-control" required placeholder="ex:Kathmandu">

</div>
<div class="form-group">
<label for="street_address">Street Address:</label>
<input type="text" name="address" class="form-control" required placeholder="ex:baneshwor">

</div>
<div class="form-group">
<label for="hotel">Hotel Name:</label>
<input type="text" name="hotel" class="form-control" required placeholder="ex: royal palace hotel">

</div>
<div class="form-group">
<label for="phone">Phone Number</label>
<input type="text" name="phone" class="form-control" required placeholder="ex:9123456132">

</div>
<div class="form-group">
<label for="email">Email</label>
<input type="email" name="email" class="form-control" required placeholder="ex:acz@gmail.com">

</div>
<div class="form-group">
<label for="price">Price for per room</label>
<input type="number" name="price" class="form-control" required placeholder="ex:1000">

</div>
<div class="form-group">
<label for="image">images</label>
<input type="file" name="images[]" class="form-control-file" required multiple><br>

</div>

	
	
</div>
	</div>
<div class="card">
<h4 class="card-title text-center">Hotel Discription</h4>
<div class="card-body">
	
<div class="form-group">

  <textarea class="form-control ckeditor" rows="5" name="discription" id="comment"></textarea>
</div>	
</div>	
</div>	
	
</div><br>
<button class="btn btn-success btn-lg mx-auto d-block"  name="published">Published</button>
</form>
	</div>

</div>
<?php }?>