
<?php
include "../header/head.php";
include "include/dbase.php";
if(isset($_GET['id'])){
	$id=$_GET['id'];
	$sql="delete from booking_details where id='$id'";
	print_r($sql);
	if($obj->insert($sql)){
		$_SESSION['delete']="<div class='text-success text-center'>sucessfully deleted</div>";
		header("location:dashboard.php");
	}
	else{
		echo "something went wrong";
	}
}
?>
