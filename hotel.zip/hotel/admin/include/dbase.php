<?php
ob_start();
session_start();

require_once "config.php";
class Database{
	
	public $host=DB_HOST;
	public $user=DB_USER;
	public $pass=DB_PASSWORD;
	public $db_name=DB_NAME;
	public $conn;
	public $error;
	
	
	public function __construct()
	{
		
		$this->conn= new mysqli($this->host,$this->user,$this->pass,$this->db_name);
		if(mysqli_connect_errno())
		{
			echo"failed connection";
			exit();
		}
		
	}
	public function insert($data){
	$result=$this->conn->query($data);
	if($result){
		
		return true;
	}else{
		return false;
	}
	}
	public function delete($signup){
	$result=$this->conn->query($signup);
	if($result){
		
		return true;
	}else{
		return false;
	}
	}
	public function check($data){    
	$chek=$this->conn->query($data);
	if($chek->num_rows>0){
	       return $chek;
	}	
		else{
			return false;
		}
	
	}
	
	public function url($url){
		header("Location:".$url);
	}
	public function session($session){
	$_SESSION['msg']= $session;
	
}

	
}
$obj=new Database;