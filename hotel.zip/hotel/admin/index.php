<?php 

      require_once "include/dbase.php";
      require_once "../header/head.php";
?>


<div class="container bg-dark">
<div class="jumbotron">
<div class="row justify-content-center ">
<div class="col-6 ">
	
<form action="index.php" method="post" class="border ml-4 mt-4">
<div>
<label>username</label>	
<input type="text" name="user" placeholder="username">
	
</div>
<div>
<label>password</label>	
<input type="password" name="password" placeholder="password">
	
</div>
	<div>
<label>phone_no</label>	
<input type="phone" name="phone" placeholder="Phone Numeber">
	
</div><br>
<button name="login" class="btn btn-primary">Login</button>
	
	
</form>	
	
</div>	
	
	
</div>	
	
</div>

</div>
<?php
if(isset($_POST['login'])){
	$username=$_POST['user'];
	$password=$_POST['password'];
	$phone=$_POST['phone'];
	$username=mysqli_real_escape_string($obj->conn,$username);
    $password=mysqli_real_escape_string($obj->conn,$password);
    $phone=mysqli_real_escape_string($obj->conn,$phone);
	$sql="select * from admin_login where username='$username'";
	if($result=$obj->check($sql)){
	$row=$result->fetch_assoc();
	if($password==$row['password'] && $phone==$row['phone_no']){
	$_SESSION['username']=$username;
	header("location:post.php");
	}
		
	else{
		echo"<div class='text-danger'>credentials donot match please <a href='../index.php'>click here....</a></div>";
	}
}
}
?>