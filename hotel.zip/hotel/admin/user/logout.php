<?php
include "../include/dbase.php";
include "../../header/head.php";
if(isset($_SESSION['msg'])){
	session_destroy();
}
	echo "<div class='text-success'><h1>Sucessfully logout! please login to continue:<a href='login.php' class='btn btn-primary'>click here</h1></div>";
	
    


?>