<?php
include "../../header/head.php";
include "../include/dbase.php";
?>
 

<div class="container">

<div class="jumbotron">
<marquee  class="bg-dark text-white"><h2> hurry up!<span>20% discount</span> </h2></marquee>
<div class="row">
<div class="col-sm-6 justify-content-center">
<form class="form-group" action="signup.php" method="post">
<div class="form-group">
<label for ="name">Full Name:</label>
<input type="text" class="form-control" placeholder="eg;ashish karki" name="name" required>
	
</div>	
<div class="form-group">
<label for ="address">Address</label>
<input type="text" class="form-control" name="address" placeholder="eg;pasupatinagar,illam" required>
	
</div>	
<div class="form-group">
<label for ="email">Email:</label>
<input type="email" class="form-control" name="email" placeholder="eg; abc@gmail.com" required>
	
</div>
<div class="form-group">
<label for ="phone">Phone Number:</label>
<input type="tel" class="form-control" placeholder="Phone Number" name="phone" required>
<div class="form-group">
<label for ="password">Password:</label>
<input type="password" class="form-control" placeholder="Password" name="password" required>	
</div> <br>
<button class="btn btn-success mx-auto d-block" name="signup">Signup</button>
	
</form>
</div>	
	
</div>	
</div>

</div>
<style>
	span{
		animation: move 2s infinite;
	}	
	@keyframes move{
		0%{color:red;}
		30%{color: orange;}
		60%{color: springgreen;}
		90%{color: darkblue;}
		100%{color: maroon;}
	}
</style>
	
	




