<?php
include "../../header/head.php";
include "../include/dbase.php";

if(isset($_POST['signup']) or isset($_GET['id'])){
$name=$_POST['name'];	
	$address=$_POST['address'];	
	$email=$_POST['email'];	
	$phone=$_POST['phone'];	
$password=$_POST['password'];
	$sql1="select * from user_signup where phone_no='$phone'";
	if(!$obj->check($sql1)){
	$phone=mysqli_real_escape_string($obj->conn,$phone);
	$password=mysqli_real_escape_string($obj->conn,$password);
	$password=password_hash($password,PASSWORD_BCRYPT);
  $sql="insert into user_signup(full_name,address,email,phone_no,password) values('$name','$address','$email','$phone','$password')";
 if($obj->insert($sql)){
	header("location:login.php"); 
  }else{
	 echo "<div class='text-danger text-center'>something went wrong please login again.......</div>";
 }
}else{
		echo "record already existed";
		/*$obj->session("<div class='text-danger'>record already existed please signup</div>");*/
	}
	}
	else{
	echo"something wrong";
}

?>