
<?php
include "../../header/head.php";
include "../include/dbase.php";
if(isset($_GET['phone'])){
	$phone=$_GET['phone'];
	$user_phone=$_SESSION['user_phone'];
    $costumer_name = $_SESSION['c_name'];
    $user_phone=mysqli_real_escape_string($obj->conn,$user_phone);
}
?>
<div class="container">
<div class="jumbotron">

<?php include_once"header/navbar.php";?>
</div>

<?php
$sql="select * from booking_details where user_phone='$phone' order by id desc ";
if($result=$obj->check($sql)){
	while($row=$result->fetch_assoc()){
		
	
?>
	
<div class="card col-sm-12 mt-4 justify-content-center" >

<h4 class="card-title text-center" >Your Bill</h4><br>
<table>
<tr><td>Hotel Name:</td><td>Check In</td> <td>Check Out</td><td>Total Price</td></tr>
<tr><td></td></tr>
<tr class="text-danger"><td><?php echo $row['hotel_name']?></td><td><?php echo $row['check_in']?></td><td><?php echo $row['check_out']?></td><td><?php echo $row['total_price']?></td></tr>

</table><br>
<a href="delete.php?id=<?php echo $row['id'];?>" class="btn btn-primary mx-auto d-block" onclick="return cancel()">Cancel Booking</a>
</div>
	<br>
<?php
	}
}else{
	echo"<div class='text-danger text-center'><h3>not book yet now</h3></div>";
}
?>



</div>
	




<script>
	function cancel(){
		return confirm("Do you want to cancel a booking");
	}
	$(document).ready(function(){
		$('.setting').click(function(){
			$('.list-group-item').toggle();
		});
	});
</script>
