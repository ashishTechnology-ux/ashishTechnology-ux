<?php
include "../../header/head.php";
include "../include/dbase.php";
$id=0;
if(isset($_POST['booking'])){

 $id=$_POST['id'];
 $amt=$_POST['price'];
 $check_in=$_POST['date1'];
 $check_out=$_POST['date2'];
 $room=$_POST['room'];
 $person=$_POST['person'];
 $price=$_POST['price'];
$sql="select * from hotel_details where id='$id'";
if($result=$obj->check($sql)){
	$row=$result->fetch_assoc();
	$hotel_name=$row['hotel_name'];
	$address=$row['street_address'];
	$hotel_phone=$row['phoneno'];

	
	
}
    $_SESSION['id']=$id;
	$_SESSION['amt']=$amt;
	$_SESSION['check_in']=$check_in;
	$_SESSION['check_out']=$check_out;
	$_SESSION['room']=$room;
	$_SESSION['person']=$person;
	$_SESSION['price']=$price;
	$_SESSION['hotel']=$hotel_name;
	$_SESSION['address']=$address;
	$_SESSION['hotel_phone']=$hotel_phone;
	
}
if(isset($_POST['login'])){
$id=$_SESSION['id'];
$phone=$_POST['phone'];	
$password=$_POST['password'];
$phone=mysqli_real_escape_string($obj->conn,$phone);
$password=mysqli_real_escape_string($obj->conn,$password);
$sql="select password,full_name from user_signup where phone_no='$phone'";

if($result=$obj->check($sql)){
  $row=$result->fetch_assoc();
  $password1=$row['password'];
  $costumer_name=$row['full_name'];
 
 if(password_verify($password,$password1)){
	 $_SESSION['user_phone']=$phone;
	 $_SESSION['c_name']=$costumer_name;
	 if($id>0){
		
		 header("location:insert_booked_details.php?phone=$phone");
	 }else{
	
	 header("location:dashboard.php?phone=$phone"); 
	 }
	
	
 }else{
	 echo"<div class='text-danger'>credentials donot match<a href='index.php?id=$id'>click here for signup..</a></div>";
 }
}else{
	echo "record not exised please signup";
	
}
}

?>
 
<div class="container">

<div class="jumbotron">

<marquee><h2> hurry up!<span>20% discount</span> </h2></marquee>
<div class="row">



<div class="col-sm-6 justify-content-center">
<form class="form-group" action="login.php" method="post">
<div class="form-group">
<label for ="phone">Phone Number:</label>
<input type="tel" class="form-control" placeholder="Phone Number" name="phone" required>
<div class="form-group">
<label for ="password">Password:</label>
<input type="password" class="form-control" placeholder="Password" name="password" required>	
</div> <br>
<button class="btn btn-success mx-auto d-block" name="login">login</button>

</form>
</div>	
	
</div>	
</div>

</div>

<style>
	span{
		animation: move 2s infinite;
	}	
	@keyframes move{
		0%{color:red;}
		30%{color: orange;}
		60%{color: springgreen;}
		90%{color: darkblue;}
		100%{color: maroon;}
	}
</style>
	
