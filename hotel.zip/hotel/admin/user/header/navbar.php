
<style>
	.list-group-item{
		display: none;
		list-style: none;
	}
</style>
<div>
<i class="fa fa-user float-left" style="font-size: 18pt;"><?php echo $costumer_name;?></i>
<ul class="list-group float-right">
<button class="setting"><i class="fa fa-cog" style="font-size: 18pt;">Setting</i>
<li class="list-group-item"><a href="booking_details.php?phone=<?php echo $user_phone;?>" class="nav-link">Your Booking</a></li>	
<li class="list-group-item"><a href="#" class="nav-link"><?php echo $user_phone;?></a></li>	
<li class="list-group-item"><a href="logout.php"  class="nav-link">Log Out</a></li>	
	 
</ul>
	


</div>