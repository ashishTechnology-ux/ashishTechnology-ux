
<?php
include "../../header/head.php";
include "../include/dbase.php";

if(isset($_SESSION['hotel_phone']) and isset($_SESSION['user_phone'])){
	$user_identify_phone=$_GET['phone'];
	$amt=$_SESSION['amt'];
	$check_in=$_SESSION['check_in'];
	$check_out=$_SESSION['check_out'];
	$room=$_SESSION['room'];
	$person=$_SESSION['person'];
	$price=$_SESSION['price'];
	$hotel_name=$_SESSION['hotel'];
	$address=$_SESSION['address'];
	$hotel_phone=$_SESSION['hotel_phone'];
    $user_phone = $_SESSION['user_phone'];
    $costumer_name = $_SESSION['c_name'];
	$sql="insert into booking_details(hotel_name,hotel_location,customer_name,user_phone,hotel_phone,total_room,total_person,total_price,check_in,check_out)values('$hotel_name','$address','$costumer_name','$user_phone','$hotel_phone','$room','$person','$price','$check_in','$check_out')";
	$obj->insert($sql);
	header("location:dashboard.php?phone=$user_identify_phone");

	
	
	
}
?>