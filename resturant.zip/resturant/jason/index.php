<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Untitled Document</title>
</head>

<body>
	<script>
	
			  
	var send={"name":"ashish","lastname":"karki"};
	var senddata=JSON.stringify(send);
	var cnvrt=JSON.parse(senddata);
		document.write(cnvrt.name);
	//window.location="send.php?values="+senddata;
	</script>
</body>
</html>