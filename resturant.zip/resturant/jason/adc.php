
<?php 
$a=json_decode(json_encode(file_get_contents("abc.json")));
$b=json_decode($a,true);
var_dump($b);
echo $b[0]['name'];
foreach($b as $arr1){
  $name= $arr1['name'];
  $race=$arr1['race'];

}
echo json_encode($array);
?>