(function($){
	var img=$('.top-img');
	var name=$('.hotel-name');
	var show=$('.view');
	t1=new TimelineLite();
	t1
	  .from(img,0.5,{x:-500,autoAlpha:0},0.7)
	  .from(name,0.6,{y:200,autoAlpha:0},0.8)
	  .from(show,1,{y:100,autoAlpha:0});
	
})(jQuery);
