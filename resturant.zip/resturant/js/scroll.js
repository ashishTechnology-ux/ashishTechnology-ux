//show/hide on scroll

var t1= new TimelineMax();
t1
.from('.anim',0.5,{y:-100,opacity:0})


var controller=new ScrollMagic.Controller();
var scene=new ScrollMagic.Scene({
triggerElement:"#content-bg",
duration:"100%"

}).setTween(t1)
  .addTo(controller);