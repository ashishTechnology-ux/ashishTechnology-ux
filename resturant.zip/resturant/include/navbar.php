<!-------------Navigation Bar------------>

<nav class="navbar navbar-expand-md bg-dark navbar-dark fixed-top">
  <!-- Brand -->
  <a class="navbar-brand" href="#">Navbar</a>

  <!-- Toggler/collapsibe Button -->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>

  <!-- Navbar links -->
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" href="/resturant/index.php">HOME</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/resturant/pages/menu.php">MENU</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/resturant/pages/news.php">NEWS</a>
      </li>
	  <li class="nav-item">
        <a class="nav-link" href="/resturant/pages/ourteam.php">OUR TEAM</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/resturant/pages/contact.php">CONTACT</a>
      </li>
      <li class="nav-item">
        <a class="nav-link" href="/resturant/pages/menu.php">RESERVATION</a>
      </li>
    </ul>
  </div>
</nav>