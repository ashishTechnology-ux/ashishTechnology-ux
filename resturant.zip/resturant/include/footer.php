<style>
	.footer{
	   background: black;
		color:white;
		opacity:0.7;
		margin-top:0px;
		height:250px;
		
	
		
	}
	.footer .content{
		display: flex;
		flex-direction: row;
	    align-content:space-around;
	
	}
#menu{
		margin-left: 220px;
	      margin-top:40px;
	
	}
	#menu span{
		margin-left: 2px;
	}
	 a{
		text-decoration: none;
		 text-underline-position: alphabetic;
		color:white;
	}
	#subscribe{
		margin-left: 100px;
		margin-top:40px;
	}
	#contact{
		margin-left:10px;
		margin-top:40px;
		
	}
	input,.btn{
		border-radius:10px;
		border:none;

	}
	/*-------- css for responsive footer start here---------*/
	@media only screen and (max-width: 710px) {
  .footer .content {
         flex-direction: column;
	     margin-left:20%;
	  
  }
		
		.footer{
	height:500px;
	}
		
}
@media only screen and (max-width: 945px) {
	#contact,#subscribe,#menu{
			margin-left:10%;
		}
	}
	@media only screen and (max-width: 835px) {
			#contact,#subscribe,#menu{
			margin-left:5%;
		}
	}
	
</style>
<div class="container-fluid footer">

<!----------------- contact section-------------->
<div class="content">
<div id="contact">
	<h4>Romeo Restuarant and bar</h4>
	<p>Address:sinCityKathmandu<br>Email:ak.bms123@gmail.com<br>Contact:+9779827378742</p>
</div>
	<!-------------- menu Secton------------>
<div id="menu">
	<h4>MENU</h4>
	<a href="">Breakfast</a><span>/</span><span><a href="">Lunch</a></span><span>/</span><span><a href="">Dinner</a></span><span>/</span><br><span><a href="">Drinks</a></span>
	</div>
	<!------------subscription----------->
	<div  id="subscribe">
		<h4>NEWS LETTER</h4>
		<span><input type="email" placeholder="Your Email"></span><span><button class="btn btn-danger ml-4">SUBSCRIBE</button></span>
	</div>	
</div>
	<!---- list of social media logo-------->
<div class="pagination ml-2 mt-4 mb-4">
<li class="page-item"><a href="#" class="fa fa-facebook page-link"></a></li>
<li class="page-item"><a href="#" class="fa fa-twitter page-link"></a></li>
<li class="page-item"><a href="#" class="fa fa-google page-link"></a></li>
<li class="page-item"><a href="#" class="fa fa-instagram page-link"></a></li>

</div>


</div>



