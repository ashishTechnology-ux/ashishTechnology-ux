<?php
/*include all CDN link */
include_once __DIR__."\include\cdn_link.php";

?>


<!----link group start------>
<!--------- css file of index.html page----------->
<link rel="stylesheet" type="text/css" href="css/index.css?ts=<?=time()?>" media="all" />

<!-----link group end--->

	
<div class="container-fluid">

	<?php include"include/navbar.php";?>
</div>

<div class="container_fluid">
<!------------ heading section-------------->
		       
	<div class="header_content ">
		
		<div class="top-img"><img src="/resturant/images/bgcartoon.png"></div>
	     <div class="hotel-name "><h3 class="text-center ">ROMIEO RESTAURANT AND BAR</h3></div>
		<div class="view text-center" >
			<a href="#show"  class="btn btn-primary text-center bg-warning">View More</a>
		</div>
	          </div>
                    </div>
            <!---------------menu section----------------->
<div class="container-fluid" id="show">
<div class="food-item"><br>
<h2 class="text-center">MENU</h2><br>
<div class="card-columns ">
	
	<div class="card">
	<div class="card-head"><h3 class="card-title text-center">FOOD NAME</h3></div>
	<img class="card-img-top" src="images/dish1.jpg" height="400px" width="400px">
	<div class="card-body"><h4 class="card-text">Description Here <br>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis, consequuntur.</h4></div>
	</div>
	<div class="card">
	<div class="card-head"><h3 class="card-title text-center">FOOD NAME</h3></div>
	<img class="card-img-top" src="images/dish2.jpg" height="400px" width="400px">
	<div class="card-body"><h4 class="card-text">Description Here <br> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis, consequuntur.</h4></div>
	</div>
	<div class="card">
	<div class="card-head"><h3 class="card-title text-center">FOOD NAME</h3></div>
	<img class="card-img-top" src="images/food.jpg" height="400px" width="400px">
	<div class="card-body"><h4 class="card-text">Description Here <br> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Perferendis, consequuntur.</h4></div>
	</div>
	 </div>	
        </div>
	        </div>
<!-------------- service section--------------->
            
	<div class="container-fluid">
	<div id="content-bg">
         <div class="anim">
			 <div id="info-img">
		<img src="images/dish1.jpg" >
		</div>
			 <div id="info"><h2 class="text-center text-white ">Enjoy Our Delicious Food</h2></div>
		
	</div>
		
		</div>
		<div class="card-columns text-center mt-4 border-0">
		<div class="card border-0">
		<i class="fas fa-hamburger fa-6x card-img-top  "></i>	
			<div class="card-body">
			<h5 class="card-title">FRESH FOOD</h5>
			<h6 class="card-text">We use only the best ingredients to cook the tasty fresh food for you.</h6>
			
			</div>
		
			</div>
			<div class="card border-0">
		<i class="fas fa-hard-hat fa-6x card-img-top  "></i>
			<div class="card-body">
			<h5 class="card-title">EXPERIENCED CHEFS</h5>
			<h6 class="card-text">Our staff consists of chefs and cooks with years of experience.</h6>
			
			</div>
		
			</div>
	
		

			<div class="card border-0">
		<i class="fas fa-drumstick-bite fa-6x card-img-top  "></i>	
			<div class="card-body">
			<h5 class="card-title">A VARIETY OF DISHES</h5>
			<h6 class="card-text">In our menu you’ll find a wide variety of dishes, desserts, and drinks.</h6>
			
			</div>
		
			</div>
		
		</div>
</div>
<div class="container-fluid">
		<div id="book-table">
			<!--------------------- booking form start here------------>
		<form class="form mx-auto d-block">
			<div class="form-group">
			
			
			<label>Phone Number:</label>
			<input type="text" placeholder="Your Phone Number" name="phone" class="form-control">
			</div>
			<div class="form-group">
			
			<label>Select Date:</label>
			<input type="date" name="date" class="form-control">
			</div>
			<div class="form-group">
			
			<label>Enter Time:</label>
			<input type="text" placeholder="Time" name="time" class="form-control">
			</div>
			<div class="form-group">
			
			<label> Select Person:</label>
			<select name="person" class="form-control">
			<option value="2person">2 person</option>
			<option value="4person">4 person</option>
				<option value="6person">6 person</option>
				<option value="8person">8 person</option>
				<option value="10person">10 person</option>
				<option value="12person">12 person</option>
				<option value="14person">14 person</option>
				<option value="16person">16 person</option>
				<option value="18person">18 person</option>
				<option value="20person">20 person</option>
				
			</select>
			
			</div>
				
				<button class="btn btn-success form mx-auto d-block">BOOK NOW</button>
		</form>	
		<!--------------------- booking form end here------------>
		
		</div>
		 <?php include"include/footer.php";?>
	</div
<!---------footer section file---------->
  

<!--- jquery script for animation--->
<script src="js/head.js"></script>
<!--------------------- animation on slide------------>
<script src="js/scroll.js"></script>