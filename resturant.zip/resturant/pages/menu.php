

<?php
/*include all CDN link */
include_once __DIR__."\..\include\cdn_link.php";

?>
<!------------- menu css file------------>
<link rel="stylesheet" type="text/css" href="../css/menu.css?ts=<?=time()?>" media="all" />



<div style="margin-bottom: 50px;"><?php include "../include/navbar.php";?></div><!--- Navigation page--->
<div class="container-fluid menu-body">

<div class="heading-text">
	<!----------------- menu Quotes------------->
	
	<h2 class="text-center heading-text">“After a good dinner one can forgive anybody,<br> even one's own relations.”</h2>
	</div>


<div class="menu-content">

<div class="menu-item">

<div class="menu-card-header text-center">
	<h4>Menus</h4>
	</div>
	<div class="menu-type">
	<!---------- menu buttons---------->
	<span><button class="button" onclick="breakfast()">Breakfast</button></span>
	<span><button class="button" onclick="lunch()">lunch</button></span>
	<span><button class="button" onclick="dinner()">Dinner</button></span>
	<span><button class="button" onclick="dinner()">Drinks</button></span>
	</div>
	<div class="food-list"></div>

	
</div>	
		
</div>

</div>
<div class="container-fluid" style="background:black"><?php include"../include/footer.php";?></div>

<!--javascript code start here-->
<script>
	
function breakfast(){
 $('.food-list').load("breakfast.php");	/* call breakfast.php page on press breakfast button*/
}
function lunch(){
 $('.food-list').load("lunch.php");	/* lunch.php page on press lunch button*/
}
function dinner(){
 $('.food-list').load("dinner.php");	/* call dinner.php page on press dinner button*/
}
	function drinks(){
 $('.food-list').load("drinks.php");	/* call dinner.php page on press dinner button*/
}
$(document).ready(function(){
 $('.food-list').load("breakfast.php");  /* call breakfast.php page on loading page*/
});


</script>