
<!------------------ display menu  on table----------->
<table style="margin-left:15%">

<thead>
	<tr>
	<th colspan="2" class="text-center">Breakfast</th>
	</tr>
	<tr>
	<th>Item Name</th>
	<th>         </th>
	<th>Price </th>
	
	</tr>
	<tbody>
	<tr>
	<td>Two Farm Fresh Eggs Any Style</td><td>................................</td> <td>$12</td>	
	</tr>
	<tr>
	<td>Buttermilk Pancakes</td><td>................................</td> <td>$11</td>	
	</tr>
	<tr>
	<td>Three Egg Omelet</td><td>................................</td> <td>$12</td>	
	</tr>
	<tr>
	<td>Toasted Bagel with Smoked Salmon</td><td>................................</td> <td>$14</td>	
	</tr>
	<tr>
	<td>Briars Breakfast Pizza</td><td>................................</td> <td>$12</td>	
	</tr>
	<tr>
	<td>French Toast</td><td>................................</td> <td>$11</td>	
	</tr>
	<tr>
	<td>Fresh Fruit Plate</td><td>................................</td> <td>$12</td>	
	</tr>
	<tr>
	<td>Coffee</td><td>................................</td> <td>$3</td>	
	</tr>
	<tr>
	<td>Tea</td><td>................................</td> <td>$3</td>	
	</tr>
	<tr>
	<td>Orange Juice</td><td>................................</td> <td>$3</td>	
	</tr>
	<tr>
	<td>Grapefruit Juice</td><td>................................</td> <td>$3</td>	
	</tr>
		<tr>
	<td>Tomato Juice</td><td>................................</td> <td>$3</td>	
	</tr>
		<tr>
	<td>Milk</td><td>................................</td> <td>$2</td>	
	</tr>
	</tbody>
	
</thead>

</table>