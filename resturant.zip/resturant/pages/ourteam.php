
<?php
/*include all CDN link */
include_once __DIR__."\..\include\cdn_link.php";

?>



<div class="container-fluid">
<?php include "../include/navbar.php";?>
<h1 class="text-center" style="margin-top:100px;">OUR TEAM</h1>
<!-- Media top -->
<div class="media mt-4">
  <img src="/../resturant/images/chef1.jpg" class="align-self-start mr-3" style="width:300px ">
  <div class="media-body">
    <h4>MR SMITH</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Est temporibus cumque, tempore eos possimus illum quisquam doloremque doloribus, magni reiciendis numquam, quo obcaecati laudantium ullam fuga neque nisi alias maiores quas aspernatur. Asperiores labore minus quasi, culpa totam aliquam officiis, ut porro aperiam animi at dolore a incidunt natus aspernatur voluptas accusamus qui magni sint, ipsam vero nostrum quaerat fugit! Deserunt quam, unde ipsam ea nobis eos, culpa harum incidunt quidem inventore aliquam! Nam harum quae, quos alias, qui aliquid, repellat debitis dolore iste provident autem eaque. Assumenda, tempora quia dolores quibusdam, fugit rerum, itaque, quod quo ex impedit eaque?</p>
  </div>
</div><br>

<!-- Media middle -->
<div class="media">
  <img src="/../resturant/images/chef2.jpg" class="align-self-center mr-3" style="width:300px">
  <div class="media-body">
    <h4>MISS KATRINA</h4>
	  
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Distinctio ad repudiandae tempore odit asperiores est, vel eveniet iure voluptatibus dicta, repellendus. Eaque, nostrum! Et nostrum quae dignissimos, rerum nesciunt numquam iure suscipit alias temporibus. Facere ducimus deserunt nobis, at numquam vero dolore dignissimos ullam, repellendus quia excepturi quod. Incidunt voluptates tempora reiciendis asperiores, voluptas eligendi omnis architecto quia esse. Ex commodi omnis dicta aperiam repellendus modi totam a voluptas, autem culpa quia doloribus, quas atque porro similique vel, provident labore inventore ea nobis nihil maxime vitae! Reiciendis molestiae tempore ipsa, eius? Dolorum alias, ipsam provident sed itaque nisi cupiditate eum.</p>
  </div>
</div><br>

<!-- Media bottom -->
<div class="media">
  <img src="/../resturant/images/chef3.jpg" class="align-self-end mr-3" style="width:300px">
  <div class="media-body">
    <h4>MR JOY</h4>
    <p>Lorem ipsum dolor sit amet, consectetur adipisicing elit. Voluptates voluptatibus accusamus eos voluptatum maiores ea dolore inventore qui dolorem minus, ipsum earum repellat omnis sequi dolorum nobis, tempore dignissimos assumenda quis porro ratione perferendis beatae corrupti? Ex nisi minus quaerat modi, id dolorum deleniti laborum est sed ducimus autem, ratione, soluta dolorem tempore quas omnis iure commodi dolores. Dolores quod pariatur aliquid, quidem fugiat sint. Eos maiores quo, quaerat harum doloremque repellat numquam culpa ea, accusantium id. Commodi minus voluptatum nostrum saepe omnis nesciunt dignissimos fugit nihil. Dolorem id, eligendi tempora consequuntur repellat corporis odio animi ea vel vero. Repellat.</p>
  </div>
</div>
	<br>
<?php include"../include/footer.php";?>
</div>
