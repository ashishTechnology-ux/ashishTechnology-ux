<!------------------ display menu  on list----------->
<ol>
<li>Starters
<ul>
<li>Soups: Soup of the Day - $2.95/$4.95 Seafood Chowder - $5.95/$7.95</li>	
<li>Lobster Bisque - $5.95/$7.95 French Onion - $3.95/$5.95</li>	
	<li>Buffalo Wings or Tenders - $9.95</li>	
	<li>Mozzarella Sticks - $4.95</li>	
	<li>Red Hook Ale Battered Popcorn Shrimp - $8.95</li>	
	<li>Onion Rings - $4.95 Sweet Potato Fries - $4.95</li>	
		
</ul>	
</li>
<li>Salad
<ul>
	<li>Caesar Selections: Plain - $8.95 With Chicken - $9.95 With Shrimp - $11.95</li>	
    <li>With Lobster: Market Price With Grilled Sirloin - $13.95 With Crab Cake - $11.95</li>	
	<li>Greek Salad- Fresh spinach, crisp romaine, tomatoes, and Greek olives, with a feta-walnut dressing. - $9.95</li>	
	<li>Spinach Salad- Fresh spinach with mushrooms, hard boiled egg, and warm bacon vinaigrette. - $9.95</li>	
	
	</ul>

</li>
<li>Specialty Sandwiches
<ul>
    <li>Crab Cake Sandwich - A delicate crab cake served on a toasted roll with lettuce and tartar sauce. $7.95</li>	
    <li>Tuscan Grilled Chicken Panini- Grilled chicken with provolone, artichoke hearts, and roasted red pesto on grilled rosemary focaccia. $9.95</li>
	<li>Southwest Turkey Club - Sliced turkey on a toasted roll with bacon, lettuce and tomatoes and avocado-ranch dressing. $9.95</li>
	<li>Mediterranean Turkey Panini - Roast turkey on grilled rosemary focaccia with a spinach-artichoke cheese sauce. $9.95</li>
	<li>Pulled Pork - Our slow roasted pork simmered in tangy BBQ sauce and served on a toasted roll with cheddar cheese. $9.95</li>
	<li>Lobster Roll - A Maine favorite. Plump lobster meat, mayo and crisp lettuce on a toasted bulky roll. Market Price</li>
</ul>	
</li>
</ol>