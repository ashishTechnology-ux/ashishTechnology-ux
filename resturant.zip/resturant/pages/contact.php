
<?php
/*include all CDN link */
include_once "../include/cdn_link.php";

?>

<link rel="stylesheet" type="text/css" href="../css/contact.css?ts=<?=time()?>" media="all" />


 <?php include "../include/navbar.php";?>
<div class="container-fluid contact-body" style="margin-top:55px;">
    
	<div id="contact-title"><h2 class="text-center mt-4">Contact Us</h2></div>
	
	<!---------------------contact form start here------------>
	<div class="row">
	<div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6 ">
		<form class="form-sm">
			<div class="form-group">
			
			
			<label>Phone Number:</label>
			<input type="text" placeholder="Your Phone Number" name="phone" class="form-control">
			</div>
			<div class="form-group">
			
			<label>Email</label>
			<input type="eamil" name="email" class="form-control">
			</div>
			
			<div class="form-group">
			
			<textarea placeholder="write message" rows="5" name="msg" class="form-control text-center">
				</textarea>
			</div>
				
				<button class="btn btn-success form mx-auto d-block">Send Message</button>
		</form>	
		<!---------------------contact form end here------------>	
		
	</div>
	<div class="col-6 col-sm-6 col-md-6 col-lg-6 col-xl-6">
	<div style="margin-left:30%;">
		<!--------------- Your Details------------->
	<h4>Direct Contact</h4>
		<h6>Tel:025-00-00</h6>
		<h6>Mobile:9827378742</h6>
		<h6>Email:merogci@gmail.com</h6>
	   <span>
		<h6>Follow Us:</h6>
		</span>
		<!-------------- Group of Social Media------------->
		<span class="pagination">
		
			<li class="page-item"><a href="#" class="fa fa-facebook page-link"></a></li>
			<li class="page-item"><a href="#" class="fa fa-twitter page-link"></a></li>
			<li class="page-item"><a href="#" class="fa fa-google page-link"></a></li>
			<li class="page-item"><a href="#" class="fa fa-instagram page-link"></a></li>


		</span>
	</div>
		
		
		
	</div>
	</div>

</div>
<div class="container-fluid" style="background: black;">
<?php include"../include/footer.php";?>
</div>


