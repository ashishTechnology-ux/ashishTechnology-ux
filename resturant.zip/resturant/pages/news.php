<?php
/*include all CDN link */
include_once __DIR__."\..\include\cdn_link.php";

?>
<style>
	/* card animated on mouse move */
	.card:hover img{
		opacity:0.7;
		content="Read More";
		transform:perspective(500px) translateZ(-10px);
		transition:all 1s;
		  box-shadow: 10px 10px 5px #aaaaaa;
	}

</style>
<?php include "../include/navbar.php";?>
<div class="container-fluid" style="margin-top:60px;">
<h1 class="text-center card-title font-weight-bold">NEWS</h1>
<div class="top-background"></div>
<!---------- Arrange News Group using Boostrap Card--->
<div class="card-columns mt-4">
<!-------------- ITEM 1--------------------->
<div class="card">
<img class="card-img-top" src="/../resturant/images/food1.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>	
	<!-------------- ITEM 2--------------------->
<div class="card">
<img class="card-img-top" src="/../resturant/images/food2.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 3--------------------->
<div class="card">
<img class="card-img-top" src="/../resturant/images/food3.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 4--------------------->
<div class="card">
<img class="card-img-top" src="/../resturant/images/food4.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 5--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food5.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div><!-------------- ITEM 6--------------------->
<div class="card">
<img class="card-img-top" src="/../resturant/images/food6.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 7--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food7.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 8--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food8.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 9--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food9.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 10--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food10.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 11--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food11.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
	<!-------------- ITEM 12--------------------->
	<div class="card">
<img class="card-img-top" src="/../resturant/images/food12.jfif">	
<div class="card-body">
<p class="card-title text-center font-weight-bold">Item Name</p>
<p class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Aspernatur autem odio iure molestiae fugit placeat ad, sit quaerat nemo cumque.</p>
</div>
<div class="card-footer">
	<button class="btn btn-success mx-auto d-block">Learn More</button>
</div>
</div>
</div>
<?php include"../include/footer.php";?>
</div>

