<?php include("header/header.php");?> 

<html>
<head>
	
<link rel="stylesheet" href="css/css.css">	
</head>
<body>
<div class="content_fade_in">

<header>
<div class="header">
<nav>
	<!-- menu_Bar--->
<?php include("header/navbar.php")?>
	</nav>
	
		<h2>Get your profession</h3>
		<h2>preparing student for sucessful future</h2>
			<div><a href="#" class="btn btn-success">Get In Touch</a><span><a href="#" class="btn btn-primary">Learn More</a></span></div><br>
	<div>
		<!-- rotating box file--->
		<?php include_once("content/facility.php")?>
	</div>
	</div>
	

</header>
	<br>
<container>


	
	<div>
	<!---about us section file-->
	<?php include("content/content1.php");?>
	</div>
	<div>
		<!---Team Section file--->
      <?php include("content/content2.php");?>
   </div>
	<div>
	<!-- testimonials section file--->
     <?php include("content/content3.php");?>
	
	</div>




</container>

	<footer>
			
	
		<!---footer section file--->
		<?php include("footer/footer.php")?>

	
	</footer>
	</div>
</body>
</html>
<script>

$(document).ready(function(){
    $('.content_fade_in').hide();
	$('.content_fade_in').fadeIn(8000);

});
</script>