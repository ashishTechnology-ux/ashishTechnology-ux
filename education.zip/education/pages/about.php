<style>

	div p{
		margin: 5vh 10vh 0vh 15vh;
		text-align: justify;
	}
</style>
<?php include_once("../header/header.php");?> 

<div class="container-fluid">

<header>
<nav>
<?php include("navbar.php")?>	
</nav>

</header>
<container>
<p class="text-center text-success"style="font-size: 20pt;font-weight: bolder">About Us</p>	
<div><p class="card-text text-center">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Vero magni repellendus dolorem, quis provident pariatur illo nesciunt laboriosam consectetur culpa distinctio quia excepturi recusandae tempora vitae magnam, ullam ratione voluptatibus, aliquid qui, autem dicta aperiam iusto nemo quam. Pariatur illo aut perspiciatis molestias, quibusdam nulla esse minima voluptas deserunt iusto eius! ex maiores alias quam sint necessitatibus dolore!</p>
</div>
</container>
<container>
<br>
<div>
<div ><?php include("../content/facility.php")?></div>	
<div class="jumbotron" style="margin-top: 250px;" ><?php include("../content/content2.php")?></div>	
<div style="margin-top: 20px;><?php include("../content/content3.php")?></div>	
</div>	
</container>


</div>