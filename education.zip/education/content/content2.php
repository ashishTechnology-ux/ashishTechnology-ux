<style>
/*  image size*/
	img{
		width:100%;
		height:500px;
	}
</style>	

<div class="container content2">
	<h2 class="text-center text-success font-weight-bold">Our Team</h2>
	<br>
  <!--- arrange contains in form of grid--->
<div class="row">
<div class="col-sm-8">
	             <!--- change heading here--->
<h2 class="font-weight-bold">Lorem ipsum dolor sit amet, consectetur.</h2>
<h4>
		  <!--- change sentences here--->
Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus cum, expedita asperiores tempora eaque amet iusto assumenda possimus voluptate consectetur maiores, ullam officia	
</h4>
</div>
<div class="col-sm-2">
  <!--- image of team mate--->
<img src="images/c21.jpg" class="img-thumbnail">
</div>
<div class="col-sm-2">
 <!--- image of team mate--->
<img src="images/c2.jpg" class="img-thumbnail">
</div>
</div>	
	
</div>