<div class="container-fluid">
<div class="jumbotron">
<h2 class="text-center font-weight-bold text-success">About Us</h2><br>
<div class="row">

<div class="col-sm-6 col-md-6 col-lg-6 ">
<img src="images/about.jpg" class="img-thumbnail" >
</div>
<div class="col-sm-6 col-md-6 col-lg-6">
                        <!--- change your text here--->
<p class="text-justify">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Ducimus cum, expedita asperiores tempora eaque amet iusto assumenda possimus voluptate consectetur maiores, ullam officia provident</p>
	<ul type="circle" style="font-family: Times New Roman;font-size: 14pt; margin-left:10px;">
	<!---include your details in list order-->
	<li>Lorem ipsum dolor sit amet</li>
	<li>Lorem ipsum dolor sit amet</li>
		<li>Lorem ipsum dolor sit amet</li>
		<li>Lorem ipsum dolor sit amet</li>
	</ul>
	<a href="#" class="btn btn-success">Learn More</a>

	
</div>	
</div>

</div>
</div>

