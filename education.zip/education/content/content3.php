 <!--- section of testimonials block--->
<div>
<div class="container-fluid">
<div class="jumbotron">
<h2 class="text-center text-success font-weight-bold">Testimonials</h2>	
<h3 class="text-center font-weight-bold">SOME OF OUR CLIENTS SAY ABOUT US</h3>
	

<div class="card-columns">
<div class="card">

<div class="card-body">
<h4 class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat enim officia quae iusto voluptas maiores assumenda, et praesentium, vero aspernatur.</h4>	

</div>
<img src="images/c2.jpg" class="card-img-bottom rounded-circle border mt-auto" style="width:100px; height:100px; margin-left:100px;">

</div>
<div class="card">

<div class="card-body">
<h4 class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat enim officia quae iusto voluptas maiores assumenda, et praesentium, vero aspernatur.</h4>	

</div>
<img src="images/c2.jpg" class="card-img-bottom rounded-circle border mt-auto" style="width:100px; height:100px; margin-left:100px;">

</div>
<div class="card">

<div class="card-body">
<h4 class="card-text">Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quaerat enim officia quae iusto voluptas maiores assumenda, et praesentium, vero aspernatur.</h4>	

</div>
<img src="images/c2.jpg" class="card-img-bottom rounded-circle border mt-auto" style="width:100px; height:100px; margin-left:100px;">

</div>

</div>	
</div>
</div>

</div>
</div>