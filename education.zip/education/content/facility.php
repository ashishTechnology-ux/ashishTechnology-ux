
<!-- rotating a box on cursor placed-->
<style>
	.rotate_card{
		width:200px;
		height: 200px;
		position: absolute;
		perspective: 500px;
	}
	.content{
		width:100%;
		height:100%;
		
	    transform-style: preserve-3d;
		border-radius: 20px;
		transition: transform 2s;        
	}
	.rotate_card:hover .content{         /* rotate block of  content on hover in y-axis*/
		transform: rotateY(180deg);
	}
	.font,.back{
		width:100%;
		height:100%;	
	    position: absolute;
		backface-visibility: hidden; /* hide backside of blocks*/    
		text-align: center;
		line-height: 200px;
		background: #193E25;;
		border-radius: 20px;
		opacity: 0.8;
	}
	.back{
	
		transform: rotateY(180deg);
		background: teal;
		
	}
	.font a{
		text-decoration: none;
		color:white;
		font-weight: lighter;
		font-size: 15pt;
	}
@media only screen and (max-width: 500px) { /* changes the size of boxes on mobile view*/
	.card_grid{
		margin-top:100px;
		padding-top:50px;
		}
		.rotate_card{
		width:150px;
		height: 150px;
		}
	.font,.back{line-height: 150px;}
	
  }

</style>
<div class="container">
<!--- bootstrap grid coding to arrange seperate  4 -3d box-->
<div class="row">

<div class="col-12 col-sm-6 col-md-3 col-lg-3" >

<div class="rotate_card"><!-- start section of 3d box-->
<div class="content">
	     <div class="font"><a href="#" >Progressive Program</a></div>
		<div class="back"><a href="#"  class="btn btn-primary" >Read More</a></div>
</div>
</div><!-- end section of 3d box-->	

</div>

<div class="col-12 col-sm-6 col-md-3 col-lg-3 card_grid">
<div class="rotate_card"><!-- start section of 3d box-->
<div class="content">
	     <div class="font"><a href="#" >Online Education</a></div>
		<div class="back"><a href="#" class="btn btn-primary">Read More</a></div>
</div>
</div><!-- end section of 3d box-->
	
</div>

<div class="col-12 col-sm-6 col-md-3 col-lg-3 card_grid">
<div class="rotate_card"><!-- start section of 3d box-->
<div class="content">
	     <div class="font"><a href="#">Clubs/Events</a></div>
		<div class="back"><a href="#" class="btn btn-primary">Read More</a></div>
</div>
</div><!-- end section of 3d box-->
	
</div>

<div class="col-12 col-sm-6 col-md-3 col-lg-3 card_grid">
<div class="rotate_card"><!-- start section of 3d box-->
<div class="content">
	     <div class="font"><a href="#" >Educational Tour</a></div>
		<div class="back"><a href="#" class="btn btn-primary">Read More</a></div>
</div>
</div><!-- end section of 3d box-->
	
</div>
</div>
