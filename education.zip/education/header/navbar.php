                     
                           <!--- menubar --->


<nav class="navbar navbar-expand-md bg-dark navbar-dark">
  <a class="navbar-brand" href="#">Educational Institute</a><!----  edit name---->
  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#collapsibleNavbar">
    <span class="navbar-toggler-icon"></span>
  </button>
  <div class="collapse navbar-collapse" id="collapsibleNavbar">
    <ul class="navbar-nav float-right" style="margin-right: 10%">
      <li class="nav-item">
        <a class="nav-link active" href="#">Home</a><!----  edit name---->
      </li>
      <li class="nav-item">
        <a class="nav-link" href="pages/about.php">About Us</a><!----  edit name---->
      </li>
      <li class="nav-item">
        <a class="nav-link" href="pages/services.php">Services</a><!----  edit name---->
      </li>  
	<li class="nav-item">
        <a class="nav-link" href="">Contacts</a><!----  edit name---->
      </li>    
    </ul>
  </div>  
</nav>

