

<div class="container-fluid bg-dark" style="height:120px;">
	
<h2 class="text-center text-white font-weight-lighter ">Contact Us:9779827378742</h2>Contact Us:9779827378742
	<h5 class="text-center text-white font-weight-lighter ">&copy ashish karki</h5>
</div>